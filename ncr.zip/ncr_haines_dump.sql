CREATE DATABASE  IF NOT EXISTS `ncr` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ncr`;
-- MySQL dump 10.13  Distrib 8.0.26, for macos11 (x86_64)
--
-- Host: 127.0.0.1    Database: ncr
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `subjectCode` varchar(12) NOT NULL,
  `courseCode` int NOT NULL,
  `courseName` varchar(128) NOT NULL,
  PRIMARY KEY (`subjectCode`,`courseCode`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`subjectCode`) REFERENCES `subject` (`subjectCode`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('CS',5001,'Intensive Intro to Computer Science'),('CS',5200,'Database Management Systems'),('CS',5330,'Pattern Recognition and Computer Vision'),('CS',5700,'Foundations of Computer Networks'),('PHYS',3601,'Classical Dynamics'),('PHYS',7302,'Electromagnetic Theory'),('THTR',2310,'History of Musical Theatre');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment`
--

DROP TABLE IF EXISTS `enrollment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollment` (
  `section` int NOT NULL,
  `student` varchar(128) NOT NULL,
  PRIMARY KEY (`section`,`student`),
  KEY `student` (`student`),
  CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`section`) REFERENCES `section` (`sectionID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `enrollment_ibfk_2` FOREIGN KEY (`student`) REFERENCES `student` (`email`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment`
--

LOCK TABLES `enrollment` WRITE;
/*!40000 ALTER TABLE `enrollment` DISABLE KEYS */;
INSERT INTO `enrollment` VALUES (1,'test@test.com'),(2,'test@test.com'),(3,'test@test.com'),(4,'test@test.com'),(4,'test2@test.com');
/*!40000 ALTER TABLE `enrollment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor`
--

DROP TABLE IF EXISTS `professor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professor` (
  `email` varchar(128) NOT NULL,
  `firstName` varchar(128) NOT NULL,
  `lastName` varchar(128) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor`
--

LOCK TABLES `professor` WRITE;
/*!40000 ALTER TABLE `professor` DISABLE KEYS */;
INSERT INTO `professor` VALUES ('b.maxwell@northeastern.edu','Bruce','Maxwell'),('d.choffnes@northeastern.edu','David','Choffnes'),('g.cooperman@northeastern.edu','Gene','Cooperman'),('k.durant@northeastern.edu','Kathleen','Durant'),('s.valcourt@northeastern.edu','Scott','Valcourt');
/*!40000 ALTER TABLE `professor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `reporter` varchar(128) NOT NULL,
  `reviewReported` int NOT NULL,
  `reportReason` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`reporter`,`reviewReported`),
  KEY `reviewReported` (`reviewReported`),
  CONSTRAINT `report_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `student` (`email`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `report_ibfk_2` FOREIGN KEY (`reviewReported`) REFERENCES `review` (`reviewID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES ('test@test.com',3,'Something offensive is written in this report'),('test@test.com',4,'offensive'),('test2@test.com',3,'Something offensive is written in this report'),('test3@test.com',3,'Something offensive is written in this report'),('test4@test.com',3,'Something offensive is written in this report');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `reviewID` int NOT NULL AUTO_INCREMENT,
  `poster` varchar(128) NOT NULL,
  `datePosted` date NOT NULL,
  `gradeReceived` varchar(3) DEFAULT NULL,
  `isMajor` tinyint(1) NOT NULL,
  `timeSpentOnClass` int NOT NULL,
  `courseDifficulty` int NOT NULL,
  `courseQuality` int NOT NULL,
  `professorQuality` int NOT NULL,
  `comments` varchar(1024) DEFAULT NULL,
  `section` int NOT NULL,
  PRIMARY KEY (`reviewID`),
  KEY `poster` (`poster`),
  KEY `section` (`section`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`poster`) REFERENCES `student` (`email`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`section`) REFERENCES `section` (`sectionID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'test@test.com','2022-04-23','A',1,5,5,7,8,'Very good course!',1),(2,'test@test.com','2022-04-24','A-',1,8,6,8,8,'Very good course!',2),(3,'test@test.com','2022-04-24','B+',1,17,8,7,7,'This was a very challenging course. Something offensive.',3),(4,'test@test.com','2022-04-30','A-',1,12,8,9,7,'This was a very challenging course. Something offensive.',4);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `review_after_insert` AFTER INSERT ON `review` FOR EACH ROW BEGIN
	INSERT INTO enrollment VALUES
    (NEW.section, NEW.poster);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section` (
  `sectionID` int NOT NULL AUTO_INCREMENT,
  `subjectCode` varchar(12) NOT NULL,
  `courseCode` int NOT NULL,
  `professor` varchar(128) NOT NULL,
  `year` int NOT NULL,
  `semester` enum('FALL','SPRING','SUMMER','WINTER') NOT NULL,
  PRIMARY KEY (`sectionID`),
  KEY `subjectCode` (`subjectCode`,`courseCode`),
  KEY `professor` (`professor`),
  KEY `semester` (`semester`,`year`),
  CONSTRAINT `section_ibfk_1` FOREIGN KEY (`subjectCode`, `courseCode`) REFERENCES `course` (`subjectCode`, `courseCode`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `section_ibfk_2` FOREIGN KEY (`professor`) REFERENCES `professor` (`email`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `section_ibfk_3` FOREIGN KEY (`semester`, `year`) REFERENCES `term` (`semester`, `year`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
INSERT INTO `section` VALUES (1,'CS',5001,'b.maxwell@northeastern.edu',2020,'FALL'),(2,'CS',5200,'k.durant@northeastern.edu',2022,'SPRING'),(3,'CS',5330,'b.maxwell@northeastern.edu',2022,'SPRING'),(4,'CS',5700,'d.choffnes@northeastern.edu',2021,'FALL');
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `email` varchar(128) NOT NULL,
  `firstName` varchar(128) NOT NULL,
  `lastName` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('test@test.com','John','Doe','password'),('test2@test.com','test','HAHAHA','password'),('test3@test.com','Test','Three','password'),('test4@test.com','Test','Four','password');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `subjectCode` varchar(12) NOT NULL,
  `subjectName` varchar(64) NOT NULL,
  PRIMARY KEY (`subjectCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES ('AACE','Arts Administration and Cultural Entrepreneurship'),('ABRB','Study Abroad - Business'),('ABRC','Study Abroad - CPS Specialty'),('ABRD','Study Abroad'),('ABRH','Study Abroad - Social Sciences and Humanities'),('ABRL','Study Abroad - Law'),('ABRS','Study Abroad - Science'),('ABRU','Study USA'),('ACC','Accounting - CPS'),('ACCT','Accounting'),('AFAM','African American Studies'),('AFRS','African Studies'),('ALY','Anthropology - CPS'),('AMSL','American Sign Language'),('ANT','Analytics - CPS'),('ANTH','Anthropology'),('ARAB','Arabic'),('ARCH','Architecture'),('ARMY','Army ROTC'),('ART','Art - CPS'),('ARTD','Art - Media Arts'),('ARTE','Art - General'),('ARTF','Art - Fundamentals'),('ARTG','Art - Design'),('ARTH','Art - History'),('ARTS','Art - Studio'),('ASNS','Asian Studies'),('BINF','Bioinformatics'),('BIO','Biology - CPS'),('BIOC','Biochemistry'),('BIOE','Bioengineering'),('BIOL','Biology'),('BIOT','Biotechnology'),('BNSC','Behavioral Neuroscience'),('BTC','Biotechnology - CPS'),('BUSN','Business Administration'),('CAEP','Counseling and Applied Educational Psychology'),('CED','Commerce and Economic Development - CPS'),('CET','Computer Engineering Technology - CPS'),('CHEM','Chemistry and Chemical Biology'),('CHM','Chemistry - CPS'),('CHME','Chemical Engineering'),('CHMY','Chemistry - CPS Specialty'),('CHNS','Chinese'),('CIVE','Civil and Environmental Engineering'),('CJS','Criminal Justice - CPS'),('CLTR','Culture'),('CMMN','Communication Studies - CPS Specialty'),('CMN','Communication Studies - CPS'),('CMS','Construction Management - CPS'),('COMM','Communication Studies'),('COOP','Cooperative Education'),('COP','Cooperative Education - CPS'),('CRIM','Criminal Justice'),('CS','Computer Science'),('CSYE','Computer Systems Engineering'),('CY','Cybersecurity'),('DA','Data Analytics'),('DAMG','Data Architecture Management'),('DEAF','Deaf Studies'),('DGM','Digital Media - CPS'),('DS','Data Science'),('EAI','Enterprise Artificial Intelligence'),('ECN','Economics - CPS'),('ECNM','Economics - CPS Specialty'),('ECON','Economics'),('EDU','Education - CPS'),('EDUC','Education'),('EEAM','Co-op/Experiential Education in Arts, Media, and Design'),('EECE','Electrical and Computer Engineering'),('EEMB','Ecology, Evolution, and Marine Biology'),('EESC','Co-op/Experiential Education in Science'),('EESH','Co-op/Experiential Education in Social Sciences and Humanities'),('EET','Electrical Engineering Technology - CPS'),('EMGT','Engineering Management'),('ENCP','Engineering Cooperative Education'),('ENG','English - CPS'),('ENGH','English - CPS Specialty'),('ENGL','English'),('ENGR','Engineering Interdisciplinary'),('ENGW','English Writing'),('ENLR','Engineering Leadership'),('ENSY','Energy Systems'),('ENTR','Entrepreneurship and Innovation'),('ENVR','Earth and Environmental Sciences'),('ENVS','Environmental Studies'),('ESC','Earth Sciences - CPS'),('ESL','English as Second Language - CPS'),('ESLG','English as a Second Language - CPS Specialty'),('EXSC','Cardiopulmonary and Exercise Science'),('FIN','Finance - CPS'),('FINA','Finance and Insurance'),('FRNH','French'),('FSEM','First-Year Seminar'),('GAME','Game Design'),('GBST','Global Studies - CPS Specialty'),('GE','General Engineering'),('GENR','General Engineering - CPS Specialty'),('GENS','General Studies'),('GET','General Engineering Technology - CPS'),('GIS','Geographic Information Systems - CPS'),('GRMN','German'),('GSND','Game Science and Design'),('GST','Global Studies - CPS'),('HBRW','Hebrew'),('HINF','Health Informatics'),('HIST','History'),('HLS','Homeland Security - CPS'),('HLTH','Health Science - Interdisciplinary'),('HMG','Health Management - CPS'),('HONR','Honors Program'),('HRM','Human Resources Management - CPS'),('HRMG','Human Resources Management'),('HSC','Health Science - CPS'),('HSCI','Health Science'),('HST','History - CPS'),('HSTR','History - CPS Specialty'),('HSV','Human Services - CPS'),('HUSV','Human Services'),('IE','Industrial Engineering'),('INAM','Interdisciplinary Studies in Arts, Media, and Design'),('INFO','Information Systems Program'),('INPR','Interdisciplinary Studies - Office of the Provost'),('INSC','Interdisciplinary Studies in Science'),('INSH','Interdisciplinary Studies in Social Sciences and Humanities'),('INT','Interdisciplinary Studies - CPS'),('INTB','International Business'),('INTL','International Affairs'),('INTP','Interpreting'),('IS','Information Science'),('ITC','Information Technology - CPS'),('ITLN','Italian'),('JPNS','Japanese'),('JRNL','Journalism'),('JWSS','Jewish Studies'),('LACS','Latin American and Caribbean Studies'),('LANG','Language - General'),('LARC','Landscape Architecture'),('LAW','Law'),('LDR','Leadership Studies - CPS'),('LING','Linguistics'),('LPSC','Law and Public Policy'),('LS','Legal Studies'),('LST','Liberal Studies - CPS'),('LW','Law (for Non-Law School Students)'),('LWP','Law and Policy - CPS'),('MATH','Mathematics'),('MATL','Materials Engineering'),('MATM','Mathematics - CPS Specialty'),('ME','Mechanical Engineering'),('MECN','Managerial Economics'),('MEIE','Mechanical and Industrial Engineering'),('MET','Mechanical Engineering Technology - CPS'),('MGMT','Management'),('MGSC','Management Science'),('MGT','Management - CPS'),('MISM','Management Information Systems'),('MKT','Marketing - CPS'),('MKTG','Marketing'),('MNSC','Management Science - CPS Specialty'),('MPNC','Music Performance - NEC'),('MSCR','Media and Screen Studies'),('MSIC','Music - CPS Specialty'),('MTH','Mathematics - CPS'),('MUS','Music - CPS'),('MUSC','Music'),('MUSI','Music Industry'),('MUST','Music Technology'),('NAVY','Navy ROTC'),('NETS','Network Science'),('NNMD','Nanomedicine'),('NPM','Nonprofit Management - CPS'),('NRSG','Nursing'),('NTR','Nutrition - CPS'),('OR','Operations Research'),('ORGB','Organizational Behavior'),('PA','Physician Assistant'),('PBR','Public Relations - CPS'),('PHDL','PhD Eperiential Leadership'),('PHIL','Philosophy'),('PHL','Philosophy - CPS'),('PHLS','Philosophy - CPS Specialty'),('PHMD','Pharmacy Practice'),('PHSC','Pharmaceutical Science'),('PHTH','Public Health'),('PHY','Physics - CPS'),('PHYC','Physics - CPS Specialty'),('PHYS','Physics'),('PJM','Project Management - CPS'),('PLSC','Political Science - CPS Specialty'),('PMC','Pharmacy - Medicinal Chemistry - CPS'),('PMCL','Pharmacology'),('PMST','Pharmaceutics'),('POL','Political Science - CPS'),('POLS','Political Science'),('PORT','Portuguese'),('PPUA','Public Policy and Urban Affairs'),('PSY','Psychology - CPS'),('PSYC','Psychology'),('PT','Physical Therapy'),('PTH','Physical Therapy - CPS'),('RFA','Regulatory Affairs of Food - CPS'),('RGA','Regulatory Affairs - CPS'),('RMS','Remote Sensing - CPS'),('RPT','Respiratory Therapy - CPS'),('RSSN','Russian'),('SBSY','Sustainable Building Systems'),('SCHM','Supply Chain Management'),('SIA','Strategic Intelligence and Analysis - CPS'),('SLPA','Speech-Language Pathology and Audiology'),('SMFA','School of the Museum of Fine Arts'),('SOC','Sociology - CPS'),('SOCL','Sociology'),('SPNS','Spanish'),('STRT','Strategy'),('SUEN','Sustainable Urban Environments'),('TCC','Technical Communications - CPS'),('TECE','Entrepreneurship Technological'),('TELE','Telecommunication Systems'),('TELR','Technology Leadership'),('THTR','Theatre'),('WMNS','Women\'s, Gender, and Sexuality Studies');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term`
--

DROP TABLE IF EXISTS `term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `term` (
  `semester` enum('FALL','SPRING','SUMMER','WINTER') NOT NULL,
  `year` int NOT NULL,
  PRIMARY KEY (`semester`,`year`),
  CONSTRAINT `term_chk_1` CHECK ((`year` between 2000 and 9999))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term`
--

LOCK TABLES `term` WRITE;
/*!40000 ALTER TABLE `term` DISABLE KEYS */;
INSERT INTO `term` VALUES ('FALL',2020),('FALL',2021),('SPRING',2021),('SPRING',2022),('SUMMER',2021);
/*!40000 ALTER TABLE `term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ncr'
--

--
-- Dumping routines for database 'ncr'
--
/*!50003 DROP FUNCTION IF EXISTS `check_professor_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `check_professor_exists`(
    var_email	VARCHAR(128)
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
		(SELECT COUNT(*)
		FROM professor
		WHERE email = var_email);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `course_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `course_exists`(
	var_subjectCode	VARCHAR(12),
    var_courseCode	INT
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
    (SELECT COUNT(*)
    FROM course
    WHERE subjectCode = var_subjectCode AND courseCode = var_courseCode);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_matching_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_matching_users`(
	var_email	VARCHAR(128),
    var_pass	VARCHAR(128)
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
    (SELECT COUNT(*) AS num
    FROM student
    WHERE email = var_email and password = var_pass);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `report_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `report_exists`(
	var_reporter	VARCHAR(128),
    var_review		INT
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
    (SELECT COUNT(*)
    FROM report
    WHERE reporter = var_reporter AND reviewReported = var_review);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `review_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `review_exists`(
	var_section	INT,
    var_poster	VARCHAR(128)
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
    (SELECT COUNT(*)
    FROM review
    WHERE section = var_section AND poster = var_poster);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `section_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `section_exists`(
	var_subjectCode	VARCHAR(12),
    var_courseCode	INT,
    var_professor	VARCHAR(128),
    var_year		INT,
    var_semester	ENUM("FALL", "SPRING", "SUMMER", "WINTER")
) RETURNS int
    DETERMINISTIC
BEGIN
	RETURN
    (SELECT COUNT(*)
    FROM section
    WHERE subjectCode = var_subjectCode AND courseCode = var_courseCode
    AND professor = var_professor AND year = var_year AND semester = var_semester);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_course` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_course`(
	var_subjectCode	VARCHAR(12),
    var_courseCode	INT,
    var_name		VARCHAR(128)
)
BEGIN
	DECLARE exist	INT;
    SET exist = course_exists(var_subjectCode, var_courseCode);
    
    IF NOT exist THEN
		INSERT INTO course (subjectCode, courseCode, courseName) VALUES
        (var_subjectCode, var_courseCode, var_name);
        COMMIT;
	END IF;
    
    SELECT exist AS exist;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_professor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_professor`(
	var_first	VARCHAR(128),
    var_last	VARCHAR(128),
    var_email	VARCHAR(128)

)
BEGIN
	DECLARE does_exist	INT;
    SET does_exist = check_professor_exists(var_email);
    
    IF NOT does_exist THEN
		INSERT INTO PROFESSOR (firstName, lastName, email) VALUES
        (var_first, var_last, var_email);
        COMMIT;
	END IF;
    
    SELECT does_exist AS exist;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_report` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_report`(
	var_reporter	VARCHAR(128),
    var_review		INT,
    var_comments	VARCHAR(1024)
)
BEGIN
	DECLARE exist	INT;
    SET exist = report_exists(var_reporter, var_review);
    
    IF NOT exist THEN
		INSERT INTO report (reporter, reviewReported, reportReason) VALUES
        (var_reporter, var_review, var_comments);
        COMMIT;
	END IF;
    
    SELECT exist AS exist;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_review` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_review`(
	var_poster	VARCHAR(128),
    var_date	DATE,
    var_grad	VARCHAR(3),
    var_isMajor	TINYINT(1),
    var_time	INT,
    var_diff	INT,
    var_course	INT,
    var_prof	INT,
    var_comm	VARCHAR(1024),
    var_section	INT
)
BEGIN
	DECLARE exist	INT;
    SET exist = review_exists(var_section, var_poster);
    
    IF NOT exist THEN
		INSERT INTO review (poster, datePosted, gradeReceived, isMajor, timeSpentOnClass, courseDifficulty, courseQuality, professorQuality, comments, section) VALUES
        (var_poster, var_date, var_grad, var_isMajor, var_time, var_diff, var_course, var_prof, var_comm, var_section);
        COMMIT;
	END IF;
    
    SELECT exist AS exist;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_section` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_section`(
	var_subjectCode	VARCHAR(12),
    var_courseCode	INT,
    var_professor	VARCHAR(128),
    var_year		INT,
    var_semester	ENUM("FALL", "SPRING", "SUMMER", "WINTER")
)
BEGIN
	DECLARE exists_section	INT;
    SET exists_section = section_exists(var_subjectCode, var_courseCode, var_professor, var_year, var_semester);
    
    IF NOT exists_section THEN
		INSERT INTO section (subjectCode, courseCode, professor, year, semester) VALUES
        (var_subjectCode, var_courseCode, var_professor, var_year, var_semester);
        COMMIT;
	END IF;
    
    SELECT exists_section AS exist;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `change_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_email`(
	var_old	VARCHAR(128),
    var_new	VARCHAR(128)
)
BEGIN
	UPDATE student
    SET email = var_new
    WHERE email = var_old;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `change_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_name`(
	var_email	VARCHAR(128),
	var_first	VARCHAR(128),
    var_last	VARCHAR(128)
)
BEGIN
	UPDATE student
    SET firstName = var_first, lastName = var_last
    WHERE email = var_email;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `change_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_password`(
	var_email	VARCHAR(128),
    new_pass	VARCHAR(128)
)
BEGIN
	UPDATE student
    SET password = new_pass
    WHERE email = var_email;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_user`(
	var_email	VARCHAR(128),
    var_first	VARCHAR(128),
    var_last	VARCHAR(128),
    var_pass	VARCHAR(128)
)
BEGIN
	DECLARE does_exist	INT;
    SET does_exist = get_matching_users(var_email, var_pass);
    
    IF NOT does_exist THEN
		INSERT INTO student (email, firstName, lastName, password) VALUES
        (var_email, var_first, var_last, var_pass);
        COMMIT;
	END IF;
    
    SELECT does_exist AS return_code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_review` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_review`(
	var_reviewID	INT
)
BEGIN
	DELETE FROM review
    WHERE reviewID = var_reviewID;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `edit_review` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `edit_review`(
	var_review	INT,
	var_grade	VARCHAR(3),
    var_isMajor	TINYINT(1),
    var_time	INT,
    var_diff	INT,
    var_courseQual	INT,
    var_profQual	INT,
    var_comments	VARCHAR(1024)
)
BEGIN
	UPDATE review
    SET gradeReceived = var_grade,
    isMajor = var_isMajor,
    timeSpentOnClass = var_time,
    courseDifficulty = var_diff,
    courseQuality = var_courseQual,
    professorQuality = var_profQual,
    comments = var_comments
    WHERE reviewID = var_review;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_course_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_course_name`(
	var_subjectCode	VARCHAR(12),
    var_courseCode	INT
)
BEGIN
	SELECT courseName
    FROM course
    WHERE subjectCode = var_subjectCode AND courseCode = var_courseCode;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_course_sections` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_course_sections`(
	var_subjectCode VARCHAR(12),
    var_courseCode	INT
)
BEGIN
	SELECT *
    FROM section
    WHERE subjectCode = var_subjectCode AND courseCode = var_courseCode;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_matching_course_codes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_matching_course_codes`(
	var_code	VARCHAR(12)
)
BEGIN
	SELECT subjectCode, courseCode, CONCAT(subjectCode, CAST(courseCode AS CHAR), " - ", courseName) AS name
    FROM course
    WHERE CONCAT(subjectCode, CAST(courseCode AS CHAR)) LIKE CONCAT("%", var_code, "%");
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_matching_course_names` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_matching_course_names`(
	var_name	VARCHAR(128)
)
BEGIN
	SELECT subjectCode, courseCode, CONCAT(subjectCode, CAST(courseCode AS CHAR), " - ", courseName) AS name
    FROM course
    WHERE courseName LIKE CONCAT("%", var_name, "%");
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_matching_professors` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_matching_professors`(
	var_name	VARCHAR(128)
)
BEGIN
	SELECT email, CONCAT(firstName, " ", lastName) AS name
    FROM professor
    WHERE CONCAT(firstName, " ", lastname) LIKE CONCAT("%", var_name, "%");
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_matching_subjects` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_matching_subjects`(
	var_sub	VARCHAR(128)
)
BEGIN
	SELECT CONCAT(subjectName, " (", CAST(subjectCode AS CHAR), ")") AS sub, subjectCode
    FROM subject
    WHERE subjectName LIKE CONCAT("%", var_sub, "%");
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_matching_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_matching_users`(
	var_email	VARCHAR(128),
    var_pass	VARCHAR(128)
)
BEGIN
	DECLARE num_matching	INT;
    SET num_matching = get_matching_users(var_email, var_pass);
    
	SELECT num_matching AS num;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_num_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_num_reports`(
	var_reviewID	INT
)
BEGIN
	SELECT COUNT(*) AS "num_reports"
    FROM report
    WHERE reviewReported = var_reviewID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_person_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_person_name`(
	var_email	VARCHAR(128)
)
BEGIN
	SELECT CONCAT(firstName, " ", lastName) AS name
    FROM
		(SELECT email, firstName, lastName
		FROM student
		UNION
		SELECT email, firstName, lastName
		FROM professor) i
	WHERE i.email = var_email;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_report_comments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_report_comments`(
	var_reporter	VARCHAR(128),
    var_review		INT
)
BEGIN
	SELECT reportReason
    FROM report
    WHERE reporter = var_reporter AND reviewReported = var_review;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_review_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_review_data`(
	var_reviewID	INT
)
BEGIN 
	SELECT *
    FROM review
    WHERE reviewID = var_reviewID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_review_reports` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_review_reports`(
	var_reviewID	INT
)
BEGIN
	SELECT *
    FROM report
    WHERE reviewReported = var_reviewID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_sections_taught` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_sections_taught`(
	var_email	VARCHAR(128)
)
BEGIN
	SELECT *
    FROM section
    WHERE professor = var_email
    ORDER BY subjectCode ASC, courseCode ASC, year DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_section_course` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_section_course`(
	var_sectionID	INT
)
BEGIN
	SELECT CONCAT(subjectCode, CAST(courseCode AS CHAR)) AS course
    FROM section
    WHERE sectionID = var_sectionID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_section_professor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_section_professor`(
	var_sectionID	INT
)
BEGIN
	SELECT CONCAT(firstName, " ", lastName) AS name
    FROM professor p,
	(SELECT professor
    FROM section
    WHERE sectionID = var_sectionID) i
    WHERE i.professor = p.email;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_section_reviewed` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_section_reviewed`(
	var_reviewID	INT
)
BEGIN
	DECLARE var_section	INT;
    SET var_section = (SELECT section
					FROM review
                    WHERE reviewID = var_reviewID);
	
    SELECT CONCAT(subjectCode, CAST(courseCode AS CHAR), " - ", semester, " ", CAST(year AS CHAR)) AS title
    FROM section
    WHERE sectionID = var_section;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_section_reviews` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_section_reviews`(
	var_sectionID	INT
)
BEGIN
	SELECT *
    FROM review
    WHERE section = var_sectionID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_section_term` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_section_term`(
	var_sectionID	INT
)
BEGIN
	SELECT CONCAT(semester, " ", CAST(year AS CHAR)) AS term
    FROM section
    WHERE sectionID = var_sectionID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_subject_sections` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_subject_sections`(
	var_code	VARCHAR(12)
)
BEGIN
	SELECT *
    FROM section
    WHERE subjectCode = var_code
    ORDER BY year DESC, courseCode ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_user_reviews` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_reviews`(
	var_email	VARCHAR(128)
)
BEGIN
	SELECT m.section, m.student, m.course, m.term, m.reviewID, m.prof
	FROM
		(SELECT *
		FROM enrollment
		LEFT JOIN
		(SELECT sectionID, CONCAT(subjectCode, CAST(courseCode AS CHAR)) AS course, CONCAT(semester, " ", CAST(year AS CHAR)) AS term, professor
		FROM section) i
		ON enrollment.section = i.sectionID
		LEFT JOIN
		(SELECT section AS sec, reviewID, poster
		FROM review) j
		ON j.sec = enrollment.section AND enrollment.student = j.poster
		LEFT JOIN
		(SELECT email, CONCAT(firstName, " ", lastName) AS prof
		FROM professor) k
		ON i.professor = k.email) m
	WHERE m.student = var_email;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-30 12:50:10
